/**
 * 
 */
package com.accumulator.StringAccumulator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Jeet
 *
 */
public class StringCalculator {

	public int add(String num) throws Exception {
		
		List<Integer> negativeValues=new ArrayList<Integer>();
		int total=0;
		if(StringUtils.isBlank(num)) {
			return 0;
		}
		//String[] arrNum=num.split(",");
		char delimiter=getDelimiter(num.split("\n")[0]);
		
		String[] arrNum =(delimiter == ',') ? num.split(",|\n") : num.split("\n|"+delimiter);
		
		for(String s: arrNum) {
			int value=Integer.parseInt(s);
			if(value<0) {
				negativeValues.add(value);
				throw new Exception("Number is less than 0 ");
			}
			total+=value;
		}
		return total;
	}
	
	private char getDelimiter(String line) {
		// TODO Auto-generated method stub
		
		if(line==null || line.isEmpty()) {
			return ',';
		}
		if(isNumeric(line)) {
			return ',';
		}
		if(line.length()==1) {
			return line.charAt(0);
		}
		return ',';
	}

	
	
	private boolean isNumeric(String line) {
		// TODO Auto-generated method stub
		
		try {
			Double.parseDouble(line);
		}catch (NumberFormatException e) {
			return false;
		}
		
		return true;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
