/**
 * 
 */
package com.accumulator.StringAccumulator;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

/**
 * @author Jeet
 *
 */
public class StringCalTest extends TestCase{

	/**
	 * @throws java.lang.Exception
	 */
	StringCalculator scal=null;
	
	@Before
	public void setUp() throws Exception {
		
		scal = new StringCalculator();
	
	}

	@Test
    public void testEmptyString() {
        try {
			assertEquals(0, scal.add(""));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	@Test
    public void testOneNumber() {
        try {
			assertEquals(3, scal.add("3"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	

    @Test
    public void testTwoNumbers() {
        try {
			assertEquals(7, scal.add("2,5"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testMoreDigitsSupported() {
        try {
			assertEquals(77, scal.add("22,55"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    @Test
    public void testAllowNnumersAsInput() {
        
        try {
			assertEquals(45, scal.add("1,2,3,4,5,6,7,8,9"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test
    public void testSupportNewLineAsSeparator() {
        
        try {
			assertEquals(6, scal.add("1\n2,3"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    @Test
    public void testNegativeNotSupported() {
       
       	try {
			assertEquals("Number is less than 0 ", scal.add("-1,4"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
		}
    
    }

}
